import React, { useEffect, useMemo, useState, useCallback } from 'react';
import * as anchor from '@coral-xyz/anchor';
import {
  PublicKey,
  SystemProgram,
  Connection,
  Transaction,
  LAMPORTS_PER_SOL,
  ComputeBudgetProgram,
} from '@solana/web3.js';
import {
  getAssociatedTokenAddress,
  createAssociatedTokenAccountInstruction,
  TOKEN_PROGRAM_ID,
  TOKEN_2022_PROGRAM_ID,
  ASSOCIATED_TOKEN_PROGRAM_ID,
  getMint,
  getAccount,
} from '@solana/spl-token';
import bs58 from 'bs58';

// ==========================================
// FIXES SUMMARY
// - Removed Node-only Buffer usage (Vite 5 no longer polyfills Node core).
//   Replaced with TextEncoder/Uint8Array & PublicKey.toBytes() where needed.
// - Replaced anchor.utils.sha256(Buffer(...)) with WebCrypto (crypto.subtle).
// - Added ASSOCIATED_TOKEN_PROGRAM_ID to create ATA instruction (explicit).
// - Removed explicit "as Buffer" casts that break in browser builds.
// - Added tiny sanity tests that run in dev to catch regressions.
// ==========================================

// ======= ENV / CONSTANTS =======
const RPC_ENDPOINT = 'https://rpc.testnet.carv.io';
const CARV_MINT = new PublicKey('D7WVEw9Pkf4dfCCE3fwGikRCCTvm9ipqTYPHRENLiw3s');
const PROGRAM_ID = new PublicKey('REPLACE_WITH_YOUR_DEPLOYED_PROGRAM_ID');
const TREASURY_PUBKEY = new PublicKey('REPLACE_WITH_YOUR_TREASURY_PUBKEY');
const GRACE_SECS = 7 * 24 * 60 * 60;
const NAME_MAX_BYTES_FOR_CURRENT_PDA = 32; // guard for current seed design
// --- Preview flag: UI only, no transactions ---
const PREVIEW_MODE = false; // live on‑chain actions enabled
const SECONDS_PER_YEAR = 365 * 24 * 60 * 60;

// ======= IDL (minimal) =======
const IDL = {
  version: '0.1.0',
  name: 'carv_naming_service',
  instructions: [
    {
      name: 'register',
      accounts: [
        { name: 'payer', isMut: true, isSigner: true },
        { name: 'nameRecord', isMut: true, isSigner: false },
        { name: 'treasury', isMut: false, isSigner: false },
        { name: 'payerAta', isMut: true, isSigner: false },
        { name: 'treasuryAta', isMut: true, isSigner: false },
        { name: 'carvMint', isMut: false, isSigner: false },
        { name: 'tokenProgram', isMut: false, isSigner: false },
        { name: 'systemProgram', isMut: false, isSigner: false },
      ],
      args: [ { name: 'name', type: 'string' }, { name: 'years', type: 'u8' } ],
    },
    {
      name: 'transfer_name',
      accounts: [ { name: 'owner', isMut: true, isSigner: true }, { name: 'nameRecord', isMut: true, isSigner: false } ],
      args: [ { name: 'name', type: 'string' }, { name: 'newOwner', type: 'publicKey' } ],
    },
    {
      name: 'set_resolver',
      accounts: [ { name: 'owner', isMut: true, isSigner: true }, { name: 'nameRecord', isMut: true, isSigner: false } ],
      args: [ { name: 'name', type: 'string' }, { name: 'newResolver', type: 'publicKey' } ],
    },
    {
      name: 'set_primary',
      accounts: [
        { name: 'owner', isMut: true, isSigner: true },
        { name: 'nameRecord', isMut: false, isSigner: false },
        { name: 'reverseRecord', isMut: true, isSigner: false },
        { name: 'systemProgram', isMut: false, isSigner: false },
      ],
      args: [ { name: 'name', type: 'string' } ],
    },
  ],
  accounts: [
    {
      name: 'NameRecord',
      type: { kind: 'struct', fields: [
        { name: 'name', type: 'string' },
        { name: 'owner', type: 'publicKey' },
        { name: 'resolver', type: 'publicKey' },
        { name: 'createdAt', type: 'i64' },
        { name: 'expiresAt', type: 'i64' },
        { name: 'initialized', type: 'bool' },
      ]},
    },
    {
      name: 'ReverseRecord',
      type: { kind: 'struct', fields: [
        { name: 'name', type: 'string' },
        { name: 'setAt', type: 'i64' },
      ]},
    },
  ],
} as const;
const ACCOUNTS_CODER = new anchor.BorshAccountsCoder(IDL as any);

// ======= Backpack-only wallet bridge =======
// Types kept minimal to avoid depending on external ambient types.
type BackpackSolana = {
  connect: () => Promise<void>;
  disconnect: () => Promise<void>;
  publicKey: PublicKey | null;
  signTransaction: (tx: Transaction) => Promise<Transaction>;
  signAllTransactions?: (txs: Transaction[]) => Promise<Transaction[]>;
};
declare global { interface Window { backpack?: { solana?: BackpackSolana } } }

function useBackpack(connection: Connection) {
  const [pubkey, setPubkey] = useState<PublicKey | null>(null);
  const provider = useMemo(() => window.backpack?.solana, []);

  const connect = async () => {
    if (!provider) throw new Error('Backpack wallet not found. Please install/open Backpack.');
    await provider.connect();
    setPubkey(provider.publicKey);
  };
  const disconnect = async () => { await provider?.disconnect(); setPubkey(null); };

  const sendTx = async (tx: Transaction): Promise<string> => {
    if (!provider?.publicKey) throw new Error('Connect Backpack first.');
    tx.feePayer = provider.publicKey;
    const { blockhash, lastValidBlockHeight } = await connection.getLatestBlockhash('confirmed');
    tx.recentBlockhash = blockhash;
    const signed = await provider.signTransaction(tx);
    const sig = await connection.sendRawTransaction(signed.serialize(), { skipPreflight: false });
    await connection.confirmTransaction({ signature: sig, blockhash, lastValidBlockHeight }, 'confirmed');
    return sig;
  };

  return { pubkey, connect, disconnect, sendTx, isInstalled: !!provider };
}

// ======= Helpers =======
const enc = new TextEncoder();
const bytes = (s: string) => enc.encode(s);
const pkBytes = (pk: PublicKey) => (typeof (pk as any).toBytes === 'function' ? (pk as any).toBytes() : (pk as any).toBuffer()); // public web3.js has toBytes in modern versions; fall back to toBuffer()

const pricePerYear = (name: string): number => {
  const n = [...name].length;
  if (n < 3) return 0;
  if (n === 3) return 1600;
  if (n === 4) return 400;
  if (n === 5) return 200;
  if (n === 6) return 100;
  return 20;
};
const isValidNameCore = (s: string) => /^[a-z0-9-]{3,64}$/.test(s);
const stripSuffix = (s: string) => s.replace(/\.carv$/i, '');
const isValidName = (s: string) => isValidNameCore(stripSuffix(s));
const explorerTx = (sig: string) => {
  const custom = encodeURIComponent(RPC_ENDPOINT);
  return `https://explorer.solana.com/tx/${sig}?cluster=custom&customUrl=${custom}`;
};
const explorerAccount = (pk: PublicKey) => {
  const custom = encodeURIComponent(RPC_ENDPOINT);
  return `https://explorer.solana.com/address/${pk.toBase58()}?cluster=custom&customUrl=${custom}`;
};
const fmtUtc = (secs: number) => {
  if (!secs) return '—';
  const d = new Date(secs * 1000);
  const y = d.getUTCFullYear(), m = String(d.getUTCMonth() + 1).padStart(2,'0'), day = String(d.getUTCDate()).padStart(2,'0');
  const hh = String(d.getUTCHours()).padStart(2,'0'), mm = String(d.getUTCMinutes()).padStart(2,'0'), ss = String(d.getUTCSeconds()).padStart(2,'0');
  return `${y}-${m}-${day} ${hh}:${mm}:${ss} UTC`;
};
const fmtDuration = (secs: number) => {
  if (secs <= 0) return '0s';
  const d = Math.floor(secs / 86400);
  const h = Math.floor((secs % 86400) / 3600);
  const m = Math.floor((secs % 3600) / 60);
  const s = secs % 60;
  const parts: string[] = [];
  if (d) parts.push(`${d}d`);
  if (h || d) parts.push(`${h}h`);
  if (m || h || d) parts.push(`${m}m`);
  parts.push(`${s}s`);
  return parts.join(' ');
};
const shorten = (s: string, a=4, b=4) => s.length <= a + b ? s : `${s.slice(0,a)}…${s.slice(-b)}`;
const utf8ByteLen = (s: string) => new TextEncoder().encode(s).length;

const namePda = (name: string) =>
  PublicKey.findProgramAddressSync([bytes('cns'), bytes(name)], PROGRAM_ID);
const reversePda = (owner: PublicKey) =>
  PublicKey.findProgramAddressSync([bytes('reverse'), pkBytes(owner)], PROGRAM_ID);

// Compute Anchor account discriminator using WebCrypto
async function accountDiscriminator(name: string): Promise<Uint8Array> {
  const preimage = enc.encode(`account:${name}`);
  const subtle: SubtleCrypto | undefined = (globalThis as any)?.crypto?.subtle;
  if (!subtle) {
    throw new Error('WebCrypto SubtleCrypto is unavailable in this environment. Make sure you are building for the browser and your tsconfig includes the DOM lib.');
  }
  const hash = await subtle.digest('SHA-256', preimage);
  return new Uint8Array(hash).slice(0, 8);
}

// ======= Types =======
type LookupState =
  | { status: 'idle' }
  | { status: 'checking' }
  | { status: 'available' }
  | { status: 'grace'; owner: string; resolver: string; expiresAt: number; graceEndsAt: number; isYours: boolean }
  | { status: 'expired'; owner: string; resolver: string; expiresAt: number }
  | { status: 'taken'; owner: string; resolver: string; expiresAt: number; isYours: boolean }
  | { status: 'error'; message: string };

type MyName = {
  pda: PublicKey;
  name: string;
  resolver: string;
  expiresAt: number;
  status: 'active' | 'grace' | 'expired';
  isPrimary: boolean;
};

export default function App() {
  const connection = useMemo(() => new Connection(RPC_ENDPOINT, 'confirmed'), []);
  const { pubkey, connect, disconnect, sendTx, isInstalled } = useBackpack(connection);

  const [mode, setMode] = useState<'auto'|'light'|'dark'>('auto');
  const [name, setName] = useState('');
  const [years, setYears] = useState(1);
  const [decimals, setDecimals] = useState<number | null>(null);
  const [tokenProgramId, setTokenProgramId] = useState(TOKEN_PROGRAM_ID);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [txSig, setTxSig] = useState<string | null>(null);

  // balances
  const [solBalance, setSolBalance] = useState<number | null>(null);
  const [carvBalance, setCarvBalance] = useState<number | null>(null);

  // availability
  const [lookup, setLookup] = useState<LookupState>({ status: 'idle' });

  // portfolio
  const [myNames, setMyNames] = useState<MyName[] | null>(null);
  const [loadingMyNames, setLoadingMyNames] = useState(false);
  const [portfolioError, setPortfolioError] = useState<string | null>(null);

  const [nowTs, setNowTs] = useState<number>(Math.floor(Date.now() / 1000));
  useEffect(() => { const id = setInterval(() => setNowTs(Math.floor(Date.now()/1000)), 1000); return () => clearInterval(id); }, []);

  // theme
  useEffect(() => {
    const root = document.documentElement;
    root.classList.remove('dark');
    if (mode === 'dark' || (mode === 'auto' && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
      root.classList.add('dark');
    }
  }, [mode]);

  // Detect mint program & decimals
  useEffect(() => {
    (async () => {
      const info = await connection.getAccountInfo(CARV_MINT, 'confirmed');
      const programId = info?.owner?.equals(TOKEN_2022_PROGRAM_ID) ? TOKEN_2022_PROGRAM_ID : TOKEN_PROGRAM_ID;
      setTokenProgramId(programId);
      const mint = await getMint(connection, CARV_MINT, 'confirmed', programId);
      setDecimals(mint.decimals);
    })().catch(() => setMessage('Unable to fetch CARV mint info.'));
  }, [connection]);

  // balances refresh
  const refreshBalances = useCallback(async () => {
    if (!pubkey) { setSolBalance(null); setCarvBalance(null); return; }
    try { const lamports = await connection.getBalance(pubkey, 'confirmed'); setSolBalance(lamports / LAMPORTS_PER_SOL); } catch { setSolBalance(null); }
    try {
      const ata = await getAssociatedTokenAddress(CARV_MINT, pubkey, false, tokenProgramId, ASSOCIATED_TOKEN_PROGRAM_ID);
      const info = await connection.getAccountInfo(ata, 'confirmed');
      if (!info) setCarvBalance(0);
      else {
        const acct: any = await getAccount(connection, ata, 'confirmed', tokenProgramId);
        const raw = typeof acct.amount === 'bigint' ? Number(acct.amount) : Number(acct.amount);
        setCarvBalance(raw / Math.pow(10, decimals ?? 0));
      }
    } catch { setCarvBalance(null); }
  }, [pubkey, connection, tokenProgramId, decimals]);
  useEffect(() => { refreshBalances().catch(() => {}); }, [refreshBalances]);

  // Derived for register panel
  const normalized = stripSuffix(name.trim().toLowerCase());
  const seedByteLen = utf8ByteLen(normalized);
  const seedTooLong = seedByteLen > NAME_MAX_BYTES_FOR_CURRENT_PDA;
  const perYear = pricePerYear(normalized);
  const totalCarv = years * perYear;
  const fullLabel = normalized ? `${normalized}.carv` : '';

  // Anchor program client
  const program = useMemo(() => {
    if (!pubkey) return null;
    const wallet = {
      publicKey: pubkey,
      signTransaction: async (tx: Transaction) => await (window.backpack!.solana!.signTransaction(tx)),
      signAllTransactions: async (txs: Transaction[]) => window.backpack!.solana!.signAllTransactions
        ? await window.backpack!.solana!.signAllTransactions!(txs)
        : Promise.all(txs.map(t => window.backpack!.solana!.signTransaction(t)))
    } as unknown as anchor.Wallet; // loosen typing to avoid .d.ts drift between wallet adapters
    const provider = new anchor.AnchorProvider(connection, wallet, { commitment: 'confirmed' });
    return new anchor.Program(IDL as any, PROGRAM_ID, provider);
  }, [connection, pubkey]);

  // Availability lookup
  useEffect(() => {
    let cancelled = false;
    const run = async () => {
      if (normalized.length < 3 || !isValidNameCore(normalized)) { setLookup({ status: 'idle' }); return; }
      if (seedTooLong) { setLookup({ status:'error', message:`Name is ${seedByteLen} bytes; limit is ${NAME_MAX_BYTES_FOR_CURRENT_PDA}.`}); return; }
      setLookup({ status: 'checking' });
      try {
        const [pda] = namePda(normalized);
        const info: any = await connection.getAccountInfo(pda, 'confirmed');
        if (!info) { if (!cancelled) setLookup({ status: 'available' }); return; }
        const decoded: any = ACCOUNTS_CODER.decode('NameRecord', info.data);
        const expiresAt = Number(decoded.expiresAt);
        const ownerPk: PublicKey = decoded.owner;
        const resolverPk: PublicKey = decoded.resolver;
        const initialized: boolean = decoded.initialized;
        if (!initialized) { if (!cancelled) setLookup({ status: 'available' }); return; }
        const isYours = !!pubkey && pubkey.equals(ownerPk);
        const now = Math.floor(Date.now()/1000);
        if (now <= expiresAt) { if (!cancelled) setLookup({ status:'taken', owner: ownerPk.toBase58(), resolver: resolverPk.toBase58(), expiresAt, isYours }); return; }
        if (now <= expiresAt + GRACE_SECS) { if (!cancelled) setLookup({ status:'grace', owner: ownerPk.toBase58(), resolver: resolverPk.toBase58(), expiresAt, graceEndsAt: expiresAt + GRACE_SECS, isYours }); return; }
        if (!cancelled) setLookup({ status:'expired', owner: ownerPk.toBase58(), resolver: resolverPk.toBase58(), expiresAt });
      } catch (e:any) { if (!cancelled) setLookup({ status:'error', message: e?.message || String(e) }); }
    };
    const t = setTimeout(run, 250);
    return () => { cancelled = true; clearTimeout(t); };
  }, [normalized, pubkey, connection, seedTooLong, seedByteLen]);

  // Helpers to create/get ATAs
  const createOrGetAtaIx = async (owner: PublicKey) => {
    const ata = await getAssociatedTokenAddress(CARV_MINT, owner, false, tokenProgramId, ASSOCIATED_TOKEN_PROGRAM_ID);
    const info = await connection.getAccountInfo(ata, 'confirmed');
    if (!info) {
      return { ata, ix: createAssociatedTokenAccountInstruction(
        pubkey!, ata, owner, CARV_MINT, tokenProgramId, ASSOCIATED_TOKEN_PROGRAM_ID
      ) };
    }
    return { ata, ix: null };
  };

  // Register for current input
  const register = async () => { if (!pubkey) return; await registerForName(normalized, years); };

  // Reusable register/renew
  const registerForName = async (targetName: string, yrs: number) => {
    try {
      setBusy(true); setMessage(null); setTxSig(null);
      if (!pubkey) throw new Error('Connect Backpack first.');
      if (!isValidNameCore(targetName)) throw new Error('Invalid name. Use 3–64 chars: a–z, 0–9, "-"');
      if (utf8ByteLen(targetName) > NAME_MAX_BYTES_FOR_CURRENT_PDA) throw new Error('Name too long for current PDA seed (32 bytes).');

      const payerAtaRes = await createOrGetAtaIx(pubkey);
      const treasuryAtaRes = await createOrGetAtaIx(TREASURY_PUBKEY);

      const [nameRecord] = namePda(targetName);
      const ix = await program!.methods
        .register(targetName, yrs)
        .accounts({
          payer: pubkey,
          nameRecord,
          treasury: TREASURY_PUBKEY,
          payerAta: payerAtaRes.ata,
          treasuryAta: treasuryAtaRes.ata,
          carvMint: CARV_MINT,
          tokenProgram: tokenProgramId,
          systemProgram: SystemProgram.programId,
        })
        .instruction();

      // Optional: compute budget (small tip for speed)
      const cuLimit = ComputeBudgetProgram.setComputeUnitLimit({ units: 200_000 });

      const tx = new Transaction().add(
        cuLimit,
        ...(payerAtaRes.ix ? [payerAtaRes.ix] : []),
        ...(treasuryAtaRes.ix ? [treasuryAtaRes.ix] : []),
        ix,
      );

      const sig = await sendTx(tx);
      setTxSig(sig);
      setMessage(`Success! ${targetName}.carv ${lookup.status==='taken' ? 'extended' : 'registered'}.`);
      await refreshBalances();
      await refreshMyNames();
    } catch (e:any) {
      setMessage(e.message ?? String(e));
    } finally { setBusy(false); }
  };

  // -------- My Names: fetch & actions --------
  const refreshMyNames = useCallback(async () => {
    if (!pubkey) { setMyNames(null); return; }
    setLoadingMyNames(true); setPortfolioError(null);
    try {
      // Use WebCrypto-based discriminator (no Node crypto)
      const disc = await accountDiscriminator('NameRecord');
      const accounts = await connection.getProgramAccounts(PROGRAM_ID, {
        commitment: 'confirmed',
        filters: [{ memcmp: { offset: 0, bytes: bs58.encode(disc) } }],
      });

      const [revPk] = reversePda(pubkey);
      const revInfo: any = await connection.getAccountInfo(revPk, 'confirmed');
      let primaryName: string | null = null;
      if (revInfo) {
        try { const rev: any = ACCOUNTS_CODER.decode('ReverseRecord', revInfo.data); primaryName = String(rev.name); } catch {}
      }

      const now = Math.floor(Date.now()/1000);
      const mine: MyName[] = [];
      for (const acc of accounts) {
        try {
          const decoded: any = ACCOUNTS_CODER.decode('NameRecord', acc.account.data as any);
          if (!decoded.initialized) continue;
          const ownerPk: PublicKey = decoded.owner;
          if (!pubkey.equals(ownerPk)) continue;
          const nm: string = String(decoded.name);
          const resolverPk: PublicKey = decoded.resolver;
          const expiresAt = Number(decoded.expiresAt);
          let status: MyName['status'] = 'expired';
          if (now <= expiresAt) status = 'active';
          else if (now <= expiresAt + GRACE_SECS) status = 'grace';
          const isPrimary = primaryName === nm;
          mine.push({ pda: acc.pubkey, name: nm, resolver: resolverPk.toBase58(), expiresAt, status, isPrimary });
        } catch {}
      }
      mine.sort((a,b) => a.expiresAt - b.expiresAt);
      setMyNames(mine);
    } catch (e:any) { setPortfolioError(e?.message ?? String(e)); setMyNames(null); }
    finally { setLoadingMyNames(false); }
  }, [connection, pubkey]);
  useEffect(() => { refreshMyNames().catch(() => {}); }, [refreshMyNames]);

  const transferName = async (row: MyName) => {
    if (!pubkey || !program) return;
    
    const input = window.prompt(`Transfer ${row.name}.carv to (recipient public key):`);
    if (!input) return; let newOwner: PublicKey; try { newOwner = new PublicKey(input.trim()); } catch { setMessage('Invalid public key'); return; }
    try {
      setBusy(true); setMessage(null); setTxSig(null);
      const sig = await program.methods
        .transfer_name(row.name, newOwner)
        .accounts({ owner: pubkey, nameRecord: row.pda })
        .rpc();
      setTxSig(sig); setMessage(`Transferred ${row.name}.carv to ${shorten(newOwner.toBase58())}`);
      await refreshMyNames();
    } catch (e:any) { setMessage(e.message ?? String(e)); } finally { setBusy(false); }
  };

  const setResolver = async (row: MyName) => {
    if (!pubkey || !program) return;
    
    const input = window.prompt(`Set resolver for ${row.name}.carv (public key):`, row.resolver);
    if (!input) return; let newResolver: PublicKey; try { newResolver = new PublicKey(input.trim()); } catch { setMessage('Invalid public key'); return; }
    try {
      setBusy(true); setMessage(null); setTxSig(null);
      const sig = await program.methods
        .set_resolver(row.name, newResolver)
        .accounts({ owner: pubkey, nameRecord: row.pda })
        .rpc();
      setTxSig(sig); setMessage(`Resolver updated for ${row.name}.carv`);
      await refreshMyNames();
    } catch (e:any) { setMessage(e.message ?? String(e)); } finally { setBusy(false); }
  };

  const setPrimary = async (row: MyName) => {
    if (!pubkey || !program) return;
    
    try {
      setBusy(true); setMessage(null); setTxSig(null);
      const [revPk] = reversePda(pubkey);
      const sig = await program.methods
        .set_primary(row.name)
        .accounts({ owner: pubkey, nameRecord: row.pda, reverseRecord: revPk, systemProgram: SystemProgram.programId })
        .rpc();
      setTxSig(sig); setMessage(`Primary name set to ${row.name}.carv`);
      await refreshMyNames();
    } catch (e:any) { setMessage(e.message ?? String(e)); } finally { setBusy(false); }
  };

  // UI helpers
  const solDisplay = solBalance == null ? '—' : solBalance.toLocaleString(undefined, { maximumFractionDigits: 6 });
  const carvDisplay = carvBalance == null ? '—' : carvBalance.toLocaleString(undefined, { maximumFractionDigits: 4 });

  const lockedByOthers = (lookup.status === 'taken' && !(lookup as any).isYours) || (lookup.status === 'grace' && !(lookup as any).isYours);

  const registerDisabled = PREVIEW_MODE || !pubkey || !isValidName(name) || seedTooLong || years < 1 || years > 10 || busy || decimals === null || lockedByOthers;

  const buttonLabel = (() => {
    if (!pubkey) return 'Connect Wallet First';
    if (busy) return 'Processing…';
    if (!fullLabel) return 'Register name';
    if (lookup.status === 'taken' && (lookup as any).isYours) return `Extend ${fullLabel}`;
    if (lookup.status === 'grace' && (lookup as any).isYours) return `Renew ${fullLabel}`;
    return `Register ${fullLabel}`;
  })();

  const registerTitle = !pubkey
    ? 'Connect Backpack to continue'
    : seedTooLong
      ? `Name is ${seedByteLen} bytes; limit is ${NAME_MAX_BYTES_FOR_CURRENT_PDA}`
      : lockedByOthers && lookup.status === 'taken'
        ? `Name is taken until ${fmtUtc((lookup as any).expiresAt)}`
        : lockedByOthers && lookup.status === 'grace'
          ? `Name is in 7-day grace until ${fmtUtc((lookup as any).graceEndsAt)}`
          : undefined;

  const graceCountdown = (() => {
    if (lookup.status !== 'grace') return null;
    const remaining = Math.max(0, (lookup as any).graceEndsAt - nowTs);
    return `${fmtDuration(remaining)} remaining`;
  })();

  // Per-row renew years state
  const [renewYears, setRenewYears] = useState<Record<string, number>>({});
  const getRenewYears = (n: string) => renewYears[n] ?? 1;
  const incRenew = (n: string, delta: number) => setRenewYears(prev => ({ ...prev, [n]: Math.max(1, Math.min(10, (prev[n] ?? 1) + delta)) }));

  // ======= Dev sanity tests (run once in browser console) =======
  useEffect(() => {
    try {
      console.assert(pricePerYear('abc') === 1600, '3-char pricing failed');
      console.assert(pricePerYear('abcd') === 400, '4-char pricing failed');
      console.assert(pricePerYear('abcde') === 200, '5-char pricing failed');
      console.assert(pricePerYear('abcdef') === 100, '6-char pricing failed');
      console.assert(pricePerYear('abcdefg') === 20, '7+ pricing failed');
      const long = 'a'.repeat(33);
      console.assert(utf8ByteLen(long) > 32, 'byte-length guard failed');
      // PDA derivation smoke test
      PublicKey.findProgramAddressSync([bytes('cns'), bytes('smoketest')], PROGRAM_ID);
      // transfer rule: only active state allows transfer
      const canTransferState = (s: 'active'|'grace'|'expired') => s === 'active';
      console.assert(canTransferState('active') && !canTransferState('grace') && !canTransferState('expired'), 'transfer rule failed');
      console.debug('[CNS] Sanity tests passed');
    } catch (e) { console.error('[CNS] Sanity tests failed', e); }
  }, []);

  return (
    <div className="container" style={{fontFamily:'Inter, system-ui, sans-serif', maxWidth: 980, margin:'0 auto', padding:16}}>
      {/* Header */}
      <div className="row" style={{display:'flex', justifyContent:'space-between', alignItems:'center', gap:12, marginBottom:12}}>
        <div className="brand" style={{display:'flex', alignItems:'center', gap:10}}>
          <img src="/brand.svg" alt="CARV Naming Service" style={{height: 32}} />
          <div>
            <div className="title" style={{fontWeight:700, fontSize:18, lineHeight:1.2}}>CARV Naming Service</div>
            <div className="subtitle" style={{fontSize:12, opacity:0.7}}>Decentralized naming on CARV SVM</div>
          </div>
        </div>
        <div className="row" style={{display:'flex', alignItems:'center', gap:10}}>
          {pubkey && (
            <>
              <div className="pill" title="Testnet SOL balance" style={{padding:'6px 10px', border:'1px solid #0002', borderRadius:999}}>◎ {solDisplay} tSOL</div>
              <div className="pill" title="CARV token balance" style={{padding:'6px 10px', border:'1px solid #0002', borderRadius:999}}>CARV {carvDisplay}</div>
            </>
          )}
          <div className="toggle" style={{display:'flex', alignItems:'center', gap:6}}>
            <span className="muted" style={{opacity:0.7}}>Theme</span>
            <select value={mode} onChange={e => setMode(e.target.value as any)}>
              <option value="auto">Auto</option>
              <option value="light">Light</option>
              <option value="dark">Dark</option>
            </select>
          </div>
          {!pubkey ? (
            <button className="btn" onClick={connect} disabled={!isInstalled} style={{padding:'8px 12px', borderRadius:8, background:'#111', color:'#fff'}}>
              {isInstalled ? 'Connect Backpack' : 'Install/Launch Backpack'}
            </button>
          ) : (
            <button onClick={disconnect} style={{padding:'8px 12px', borderRadius:8}}>Disconnect</button>
          )}
        </div>
      </div>

      {/* Hero */}
      <div className="card" style={{padding:16, border:'1px solid #0002', borderRadius:12, background:'linear-gradient(180deg,#ffffff, #f8fbff)'}}>
        <div className="headline" style={{fontSize:24, fontWeight:700}}>Claim your <span style={{background:'linear-gradient(90deg,#6ae3ff,#7a5cff)', WebkitBackgroundClip:'text', color:'transparent'}}>.carv</span> name</div>
        <div className="subline" style={{opacity:0.8}}>Register a human-readable name that resolves to your wallet on the CARV SVM Chain.</div>
      </div>

      {/* Registration card */}
      <div className="card" style={{marginTop:16, marginBottom:16, padding:16, border:'1px solid #0002', borderRadius:12}}>
        <div className="row" style={{display:'flex', justifyContent:'space-between', gap:10, alignItems:'center'}}>
          <div className="name-input" style={{display:'flex', alignItems:'center', gap:6, flex:1}}>
            <input
              className="grow"
              placeholder="yourname"
              value={name}
              onChange={(e) => setName(e.target.value.toLowerCase())}
              maxLength={69}
              style={{flex:1, padding:'10px 12px', border:'1px solid #0003', borderRadius:8}}
            />
            <span className="suffix" style={{fontWeight:600, background:'linear-gradient(90deg,#6ae3ff,#7a5cff)', WebkitBackgroundClip:'text', color:'transparent'}}>.carv</span>
          </div>
          <div className="row" style={{display:'flex', alignItems:'center', gap:8}}>
            <button onClick={() => setYears(Math.max(1, years-1))} style={{padding:'6px 10px'}}>−</button>
            <div className="pill" style={{padding:'6px 12px', border:'1px solid #0002', borderRadius:999}}>{years} year{years>1?'s':''}</div>
            <button onClick={() => setYears(Math.min(10, years+1))} style={{padding:'6px 10px'}}>+</button>
          </div>
        </div>

        {normalized && (
          <div style={{ marginTop: 6 }}>
            <span style={{opacity: seedTooLong ? 1 : 0.7, color: seedTooLong ? '#c62828' : 'inherit'}}>
              PDA seed bytes: <b>{seedByteLen}</b> / {NAME_MAX_BYTES_FOR_CURRENT_PDA}
              {seedTooLong && ' — too long for current program version'}
            </span>
          </div>
        )}

        <div style={{marginTop:12, display:'flex', justifyContent:'space-between'}}>
          <div className="muted" style={{opacity:0.8}}>
            {normalized.length < 3 ? 'Minimum 3 characters.' : <>Price: <b>{perYear}</b> CARV / year</>}
          </div>
          <div><b>Total:</b> {totalCarv} CARV</div>
        </div>

        {/* Availability */}
        <div style={{marginTop:12, borderTop:'1px solid #0001', paddingTop:12}}>
          <div className="row" style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
            <div style={{fontWeight:600}}>Availability</div>
            <div className="muted" style={{opacity:0.8}}>Status updates as you type</div>
          </div>

          <div style={{marginTop:8}}>
            {normalized.length < 3 || !isValidNameCore(normalized) ? (
              <div className="muted" style={{opacity:0.8}}>Enter 3–64 characters (a–z, 0–9, “-”).</div>
            ) : lookup.status === 'checking' ? (
              <div>Checking…</div>
            ) : lookup.status === 'available' ? (
              <div><span className="pill" style={{padding:'4px 8px', border:'1px solid #0002', borderRadius:999}}>Available</span></div>
            ) : lookup.status === 'grace' ? (
              <div>
                <span className="pill" style={{padding:'4px 8px', borderRadius:999, background:'#ffddaa'}}>In 7-day grace (owner-only)</span>
                <div className="muted" style={{marginTop:6, opacity:0.8}}>
                  Owner: {shorten((lookup as any).owner)} • Resolver: {shorten((lookup as any).resolver)} • Expired at: {fmtUtc((lookup as any).expiresAt)} • Grace ends: {fmtUtc((lookup as any).graceEndsAt)}
                </div>
                <div style={{marginTop:6}}><b>Warning:</b> {graceCountdown}</div>
                <div style={{marginTop:6}}><b>Note:</b> Transfers are <u>disabled</u> during grace; the owner can only renew.</div>
              </div>
            ) : lookup.status === 'expired' ? (
              <div>
                <span className="pill" style={{padding:'4px 8px', border:'1px solid #0002', borderRadius:999}}>Expired — re-registerable</span>
                <div className="muted" style={{marginTop:6, opacity:0.8}}>
                  Previous owner: {shorten((lookup as any).owner)} • Resolver: {shorten((lookup as any).resolver)} • Expired at: {fmtUtc((lookup as any).expiresAt)}
                </div>
              </div>
            ) : lookup.status === 'taken' ? (
              <div>
                <span className="pill" style={{padding:'4px 8px', border:'1px solid #0002', borderRadius:999}}>{(lookup as any).isYours ? 'Taken — Yours' : 'Taken'}</span>
                <div className="muted" style={{marginTop:6, opacity:0.8}}>
                  Owner: {shorten((lookup as any).owner)} • Resolver: {shorten((lookup as any).resolver)} • Expires at: {fmtUtc((lookup as any).expiresAt)}
                </div>
              </div>
            ) : lookup.status === 'error' ? (
              <div style={{color:'#c62828'}}>Lookup error: {(lookup as any).message}</div>
            ) : null}
          </div>
        </div>

        <div className="row" style={{marginTop:12, display:'flex', alignItems:'center', gap:10}}>
          <button className="btn" onClick={register} disabled={registerDisabled} title={registerTitle} style={{padding:'10px 14px', borderRadius:8, background: registerDisabled ? '#999' : '#111', color:'#fff'}}>
            {buttonLabel}
          </button>
          <div className="muted" style={{opacity:0.8}}>Payments in CARV • Fees in testnet SOL • On-chain</div>
        </div>

        {message && <div style={{marginTop:12}}>{message}</div>}
        {txSig && (
          <div style={{marginTop:8}}>
            View transaction:&nbsp;<a href={explorerTx(txSig)} target="_blank" rel="noreferrer">{txSig}</a>
          </div>
        )}
      </div>

      {/* ---------- My Names portfolio ---------- */}
      <div className="card" style={{marginTop:16, padding:16, border:'1px solid #0002', borderRadius:12}}>
        <div className="row" style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
          <div style={{fontWeight:700}}>My Names</div>
          <div className="row" style={{display:'flex', gap:8}}>
            <button onClick={() => refreshMyNames()} style={{padding:'6px 10px'}}>Refresh</button>
          </div>
        </div>

        {!pubkey ? (
          <div className="muted" style={{marginTop:8, opacity:0.8}}>Connect Backpack to view your names.</div>
        ) : loadingMyNames ? (
          <div style={{marginTop:8}}>Loading…</div>
        ) : portfolioError ? (
          <div style={{marginTop:8, color:'#c62828'}}>Error: {portfolioError}</div>
        ) : !myNames || myNames.length === 0 ? (
          <div className="muted" style={{marginTop:8, opacity:0.8}}>No names yet.</div>
        ) : (
          <div style={{marginTop:10}}>
            {myNames.map((row) => {
              const now = nowTs;
              const graceEnds = row.expiresAt + GRACE_SECS;
              const remaining = row.status === 'active' ? row.expiresAt - now : row.status === 'grace' ? graceEnds - now : 0;
              return (
                <div key={row.pda.toBase58()} style={{display:'grid', gridTemplateColumns:'1.4fr 1fr 1.1fr 1.6fr 0.6fr', gap:10, alignItems:'center', padding:'10px 0', borderTop:'1px solid #0001'}}>
                  <div>
                    <div style={{fontWeight:600}}>
                      {row.name}.carv {row.isPrimary && <span className="pill" title="Primary name" style={{marginLeft:6, padding:'2px 6px', border:'1px solid #0002', borderRadius:999}}>Primary</span>}
                    </div>
                    <div className="muted" style={{fontSize:13, opacity:0.8}}>Resolver: {shorten(row.resolver)}</div>
                  </div>
                  <div>
                    <div className="muted" style={{fontSize:13, opacity:0.8}}>Expires</div>
                    <div>{fmtUtc(row.expiresAt)}</div>
                  </div>
                  <div>
                    <div className="muted" style={{fontSize:13, opacity:0.8}}>Status</div>
                    {row.status === 'active' && <div><span className="pill" style={{padding:'2px 6px', border:'1px solid #0002', borderRadius:999}}>Active</span> <span className="muted" style={{opacity:0.8}}>{fmtDuration(Math.max(0, remaining))}</span></div>}
                    {row.status === 'grace' && <div><span className="pill" style={{padding:'2px 6px', borderRadius:999, background:'#ffddaa'}}>In grace</span> <span className="muted" style={{opacity:0.8}}>{fmtDuration(Math.max(0, remaining))} left</span></div>}
                    {row.status === 'expired' && <div><span className="pill" style={{padding:'2px 6px', border:'1px solid #0002', borderRadius:999}}>Expired</span></div>}
                  </div>
                  <div>
                    <div className="muted" style={{fontSize:13, opacity:0.8}}>Actions</div>
                    <div className="row" style={{display:'flex', gap:6, flexWrap:'wrap'}}>
                      <button onClick={() => incRenew(row.name, -1)} style={{padding:'4px 8px'}}>−</button>
                      <div className="pill" style={{padding:'4px 8px', border:'1px solid #0002', borderRadius:999}}>{getRenewYears(row.name)}y</div>
                      <button onClick={() => incRenew(row.name, +1)} style={{padding:'4px 8px'}}>+</button>
                      <button className="btn" disabled={busy} onClick={() => registerForName(row.name, getRenewYears(row.name))} style={{padding:'6px 10px', borderRadius:8}}>
                        {row.status === 'active' ? 'Extend' : row.status === 'grace' ? 'Renew' : 'Re-register'}
                      </button>
                      <button disabled={busy || row.status !== 'active'} onClick={() => transferName(row)} style={{padding:'6px 10px'}}>Transfer</button>
                      <button disabled={busy || row.isPrimary || row.status === 'expired'} onClick={() => setPrimary(row)} style={{padding:'6px 10px'}}>Set primary</button>
                      <button onClick={() => setResolver(row)} disabled={busy} style={{padding:'6px 10px'}}>Set resolver</button>
                    </div>
                  </div>
                  <div style={{textAlign:'right'}}>
                    <a href={explorerAccount(row.pda)} target="_blank" rel="noreferrer">View</a>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      <div style={{marginTop:12, opacity:0.8}} className="muted">
        • Allowed characters: <code>a–z</code>, <code>0–9</code>, <code>-</code> • 3–64 chars<br/>
        • In grace, only the current owner can renew (transfer is blocked); after 7 days anyone can re-register.<br/>
        • All actions are on-chain; transactions will appear in the explorer.
      </div>
    </div>
  );
}
